using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.SystemWebAdapters;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddAuthentication("Cookies")
    .AddCookie("Cookies", options =>
    {
        options.Cookie.Name = ".MyApp.Auth";
        options.LoginPath = "http://localhost:5000/Login.aspx";
    });

builder.Services.AddAuthorization();
builder.Services.AddRazorPages();
builder.Services.AddSystemWebAdapters().AddCookieScheme("Cookies");

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
app.UseSystemWebAdapters();
app.MapRazorPages();
app.Run();