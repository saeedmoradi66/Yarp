using System;
using System.Web;
using Microsoft.AspNetCore.SystemWebAdapters;

public class Global : HttpApplication
{
    protected void Application_Start(object sender, EventArgs e)
    {
        SystemWebAdapterConfiguration
            .AddSystemWebAdapters()
            .AddRemoteAppAuthentication();
    }
}