using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.SystemWebAdapters;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddAuthentication("Cookies")
    .AddCookie("Cookies", options =>
    {
        options.Cookie.Name = ".MyApp.Auth";
        options.LoginPath = "/Login.aspx";
    });

builder.Services.AddAuthorization();
builder.Services.AddSystemWebAdapters().AddCookieScheme("Cookies");
builder.Services.AddReverseProxy().LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
app.UseSystemWebAdapters();

app.Use(async (context, next) =>
{
    var path = context.Request.Path.Value?.ToLowerInvariant();
    if (path?.Contains("login.aspx") == true || path.EndsWith(".css") || path.EndsWith(".js")) { await next(); return; }
    if (!context.User.Identity?.IsAuthenticated ?? true)
    {
        context.Response.Redirect("/Login.aspx");
        return;
    }
    await next();
});

app.MapReverseProxy();
app.Run();