using System;
using System.Web;
using System.Web.Security;

namespace LegacyWebApp
{
    public partial class Login : System.Web.UI.Page
    {
        protected void LoginButton_Click(object sender, EventArgs e)
        {
            if (UsernameTextBox.Text == "admin" && PasswordTextBox.Text == "123")
            {
                FormsAuthentication.SetAuthCookie("admin", false);
                Response.Redirect("Default.aspx");
            }
            else
            {
                ErrorLabel.Text = "Invalid credentials";
            }
        }
    }
}